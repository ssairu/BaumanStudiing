#include "MyString.h"


MyString::MyString(char *a, int n) {
	this->str = new char[n];
	this->length = n;
	for (int i = 0; i < n; i++) {
		this->str[i] = a[i];
	}
}

char* MyString::getStr() { return str; }

int MyString::len() { return length; }

//int& MyString::operator[](int i) {}

void MyString::setChar(int i, char x) { str[i] = x; }

bool MyString::Polyndrom() {
	bool res = true;
	for (int i = 0; 2 * i < length; i++) {
		if (str[i] != str[length - i - 1])
			res = false;
	}
	return res;
}
